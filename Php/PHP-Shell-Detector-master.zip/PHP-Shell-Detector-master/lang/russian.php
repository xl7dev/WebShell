<?php
  $local = array();
  $local['Starting file scanner, please be patient file scanning can take some time.'] = 'Начинаю сканирование файлов, будте терпеливы данная процедура может занят некоторе время';
  $local['Number of known shells in database is: '] = 'Количество опознаных шелл скриптов в базе данных: ';
  $local['Files found:'] = 'Файлов найдено:';
  $local['File limit reached, scanning process stopped.'] = 'Достигнуто максимальное кол-во файлов, процесс поиска файлов остановлен';
  $local['File scan done we have: @count files to analize'] = 'Процесс поиска файлов окончен, найдено @count файлов для анализа';
  $local['Owner:'] = 'Владелец файла:';
  $local['Permission:'] = 'Права файла:';
  $local['Last accessed:'] = 'Дата последнего доступа:';
  $local['Last modified:'] = 'Дата последней модификации:';
  $local['Filesize:'] = 'Размер файла:';
  $local['suspicious functions used:'] = 'использованы подозрительные функции';
  $local['line:'] = 'строка';
  $local['<strong>Status</strong>: @count suspicious files found and @shells shells found'] = '<strong>Статус</strong>: найдено @count подозрительных файлов из них @shells опознаны как веб шелл';
  $local['Negative'] = '';
  //$local[''] = '';
?>
