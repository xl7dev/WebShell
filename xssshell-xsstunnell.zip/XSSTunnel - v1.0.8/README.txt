-------------------------
XSS TUNNEL v1.0.8	- 26/06/2007
-------------------------
Ferruh Mavituna

-------------------------
WHAT IS XSS TUNNEL ?
-------------------------
A tool to tunnel standard HTTP Traffic through XSS Channels.

-------------------------
LICENCE
-------------------------
GPL

-------------------------
DOCUMENTATION
------------------------
XSS Tunnelling Paper (XSSTunnelling.pdf) which includes documentation. 

-------------------------
INSTALL
-------------------------
Requirements : Windows and .NET Framework 2

.NET Framework 2 can be installed from Windows Update or from following URL : 
http://www.microsoft.com/downloads/details.aspx?FamilyID=0856EACB-4362-4B0D-8EDD-AAB15C5E04F5&displaylang=en 

1) Copy XSSTunnel.exe and XSSTunnelLib.dll to a folder and run XSSTunnel.exe
2) Setup a XSS Shell server to get it to work. The XSS Shell should be version 0.6.0 or newer.

Installition and configuration video;
http://ferruh.mavituna.com/makale/xss-shell-install-video/


-------------------------
CONTACT
-------------------------
ferruh-at-mavituna.com
http://ferruh.mavituna.com